jQuery(document).ready(function(){

    // NAVIGATION JS : START
    jQuery.each(jQuery('.nav .navbox > ul > li:has(ul)'), function() {
        jQuery(this).addClass('has-dropdown');
        jQuery(this).find('>a').after('<span class="dropdown-icon"><i class="fa fa-chevron-down"></i></span>');
    });
    jQuery.each(jQuery('.nav .navbox > ul > li > ul > li:has(ul)'), function() {
        jQuery(this).addClass('has-dropdown');
        jQuery(this).find('>a').after('<span class="dropdown-icon"><i class="fa fa-chevron-right"></i></span>');
    });

        jQuery('.nav .action.toggle').click(function(e){
            e.preventDefault();
            jQuery('.nav .navbox').toggleClass('active');
        });
        jQuery('.nav .action.close').click(function(e){
            e.preventDefault();
            jQuery('.nav .navbox').removeClass('active');
        });
        jQuery('.nav .navbox > ul > li:has(ul)').click(function(e) {
            var container = jQuery(this).find('ul');
            if (!container.is(e.target) && container.has(e.target).length === 0) {
                jQuery(this).find('>ul').slideToggle();
                jQuery(this).find('>span.dropdown-icon .fas').toggleClass('fa-chevron-down');
                jQuery(this).find('>span.dropdown-icon .fas').toggleClass('fa-chevron-up');
            }
        });
        jQuery('.nav .navbox > ul > li > ul > li:has(ul)').click(function(e) {
            var container = jQuery(this).find('ul');
            if (!container.is(e.target) && container.has(e.target).length === 0) {
                jQuery(this).find('>ul').slideToggle();
                jQuery(this).find('>span.dropdown-icon .fas').toggleClass('fa-chevron-right');
                jQuery(this).find('>span.dropdown-icon .fas').toggleClass('fa-chevron-up');
            }
        });

    // NAVIGATION JS : END

});

  var forEach=function(t,o,r){if("[object Object]"===Object.prototype.toString.call(t))for(var c in t)Object.prototype.hasOwnProperty.call(t,c)&&o.call(r,t[c],c,t);else for(var e=0,l=t.length;l>e;e++)o.call(r,t[e],e,t)};
  var hamburgers = document.querySelectorAll(".hamburger");
  if (hamburgers.length > 0) {
  forEach(hamburgers, function(hamburger) {
  hamburger.addEventListener("click", function() {
  this.classList.toggle("is-active");
  }, false);
  });
  }

function toggleNav() {
}

$(document).ready(function () {
              var url = window.location;
              $('.navbox li a[href="'+ url +'"]').addClass('active');
              $('.navbox li a').filter(function() {
                        return this.href == url;
              }).addClass('active');
      });



  // $(function(){

  //   createSticky($("#header"));

  // });

  // function createSticky(sticky) {

  //   if (typeof sticky !== "undefined") {

  //    // var pos = sticky.offset().top
  //         win = $(window);

  //     win.on("scroll", function() {
  //         win.scrollTop() >= pos ? sticky.addClass("fixed") : sticky.removeClass("fixed");
  //     });
  //   }
  // }
